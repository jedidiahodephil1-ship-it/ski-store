const menu=document.getElementById("menu");
const nav=document.getElementById("nav");
menu?.addEventListener("click",()=>nav.classList.toggle("open"));
nav?.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>nav.classList.remove("open")));

const observer=new IntersectionObserver(entries=>{
  entries.forEach(entry=>{if(entry.isIntersecting)entry.target.classList.add("show")});
},{threshold:.1});
document.querySelectorAll(".skill-grid article,.project,.service-grid article").forEach(el=>{
  el.classList.add("reveal");observer.observe(el);
});

document.getElementById("contactForm").addEventListener("submit",e=>{
  e.preventDefault();
  document.getElementById("formMessage").textContent="Thanks — your message is ready to be connected to your email service.";
  e.target.reset();
});