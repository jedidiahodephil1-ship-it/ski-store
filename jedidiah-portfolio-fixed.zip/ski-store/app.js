const products=[
{id:1,name:"SKI White Tee",type:"shirts",price:30000,image:"ski-shirt.jpg"},
{id:2,name:"SKI Black Hoodie",type:"hoodies",price:55000,image:"ski-hoodie.jpg"},
{id:3,name:"SKI Black Cap",type:"accessories",price:22000,image:"ski-cap.jpg"},
{id:4,name:"SKI Essential Socks",type:"accessories",price:12000,image:"ski-socks.jpg"}];

let cart=JSON.parse(localStorage.getItem("skiCartOnly")||"[]");
const money=n=>"₦"+n.toLocaleString("en-NG");
const productsEl=document.getElementById("products");

function renderProducts(filter="all"){
const list=filter==="all"?products:products.filter(p=>p.type===filter);
productsEl.innerHTML=list.map(p=>`<article class="product"><div class="photo"><img src="${p.image}" alt="${p.name}"></div><div class="info"><div><div class="name">${p.name}</div><span class="type">${p.type}</span></div><strong class="price">${money(p.price)}</strong></div><button class="add" data-add="${p.id}">ADD TO BAG</button></article>`).join("");
}
function renderCart(){
const el=document.getElementById("cartItems");
if(!cart.length)el.innerHTML='<p>YOUR BAG IS EMPTY.</p>';
else el.innerHTML=cart.map(i=>`<div class="item"><div class="item-photo"><img src="${i.image}" alt="${i.name}"></div><div><h3>${i.name}</h3><p>${money(i.price)}</p><div class="qty"><button data-minus="${i.id}">−</button><span>${i.qty}</span><button data-plus="${i.id}">+</button></div></div><strong>${money(i.price*i.qty)}</strong></div>`).join("");
const count=cart.reduce((a,i)=>a+i.qty,0),total=cart.reduce((a,i)=>a+i.price*i.qty,0);
document.getElementById("bagCount").textContent=count;
document.getElementById("cartTotal").textContent=money(total);
localStorage.setItem("skiCartOnly",JSON.stringify(cart));
}
productsEl.onclick=e=>{const b=e.target.closest("[data-add]");if(!b)return;const id=+b.dataset.add,p=products.find(x=>x.id===id),i=cart.find(x=>x.id===id);i?i.qty++:cart.push({...p,qty:1});renderCart();openCart()};
document.getElementById("cartItems").onclick=e=>{const p=e.target.closest("[data-plus]"),m=e.target.closest("[data-minus]");if(p)cart.find(i=>i.id==p.dataset.plus).qty++;if(m){const i=cart.find(x=>x.id==m.dataset.minus);i.qty--;if(i.qty<1)cart=cart.filter(x=>x.id!==i.id)}renderCart()};
document.querySelector(".filters").onclick=e=>{const b=e.target.closest("button");if(!b)return;document.querySelectorAll(".filters button").forEach(x=>x.classList.remove("active"));b.classList.add("active");renderProducts(b.dataset.filter)};
const cartEl=document.getElementById("cart"),shade=document.getElementById("shade");
function openCart(){cartEl.classList.add("open");shade.classList.add("active")}function closeCart(){cartEl.classList.remove("open");shade.classList.remove("active")}
document.getElementById("bagButton").onclick=openCart;document.getElementById("closeCart").onclick=closeCart;shade.onclick=closeCart;
document.getElementById("checkout").onclick=()=>{if(cart.length){alert("Order received. SKI will contact you to confirm delivery.");cart=[];renderCart();closeCart()}};
document.getElementById("newsletter").onsubmit=e=>{e.preventDefault();alert("You are on the SKI list.");e.target.reset()};
renderProducts();renderCart();